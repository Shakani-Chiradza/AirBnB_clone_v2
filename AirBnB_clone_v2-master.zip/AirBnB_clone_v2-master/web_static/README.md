This part of the AriBnB clone is the web static part where we will create
HTML and CSS styling