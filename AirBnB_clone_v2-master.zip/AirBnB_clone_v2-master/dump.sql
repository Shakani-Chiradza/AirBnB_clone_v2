-- Drop database
DROP DATABASE IF EXISTS hbnb_dev_db;